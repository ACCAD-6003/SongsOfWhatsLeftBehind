﻿using System;

namespace RhythmGame
{
    [Flags]
    public enum NoteType
    {
        First = 1,
        Second = 2,
        Third = 4,
        Fourth = 8,
    }
}