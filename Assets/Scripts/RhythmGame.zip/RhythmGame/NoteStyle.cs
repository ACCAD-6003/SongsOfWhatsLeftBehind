﻿namespace RhythmGame
{
    public enum NoteStyle
    {
        Single,
        Hold,
    }
}